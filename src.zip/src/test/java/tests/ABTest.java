package tests;

import org.junit.jupiter.api.Test;
import pages.ABPage;
import pages.GetByTextPage;

public class ABTest extends BaseTest{

    @Test
    void clickABTest(){
        ABPage abPage = new ABPage(page);
      //  abPage.abTestingLink.click();

        GetByTextPage textPage = new GetByTextPage(page);
        textPage.locatorGetByText.click();
    }
}
