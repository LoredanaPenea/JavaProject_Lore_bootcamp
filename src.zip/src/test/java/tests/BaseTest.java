package tests;

import com.microsoft.playwright.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;

public class BaseTest {
    protected Playwright playwright;
    protected BrowserContext context;
    protected BrowserContext secondContext;
    protected Page page;
    protected Page tab2;
    protected Page thirdTab;

    @BeforeEach
    void setup() {
        playwright = Playwright.create();
        Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));

        context = browser.newContext();
        page = context.newPage();
        page.navigate("https://the-internet.herokuapp.com/");
        //tab2=context.newPage();
        //tab2.navigate("https://www.google.com/");

        //new Chrome browser window
        // secondContext=browser.newContext();
        // thirdTab=secondContext.newPage();
        // thirdTab.navigate("https://www.google.com/");

    }

    @AfterEach
    void tearDown() throws InterruptedException {
        Thread.sleep(10000);
    }

}
