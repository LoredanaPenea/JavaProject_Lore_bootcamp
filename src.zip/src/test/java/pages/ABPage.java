package pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

public class ABPage extends BasePage{
    public Locator abTestingLink;

    public ABPage(Page page) {
        super(page);
        abTestingLink = page.getByRole(AriaRole.LINK,new Page.GetByRoleOptions().setName("A/B Testing"));
    }

}
